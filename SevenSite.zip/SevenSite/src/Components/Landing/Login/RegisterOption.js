import React from "react";
import "./Login.css";
function RegisterOption() {
  return (
    <div className="loginPanel">
      <div class="main">
        <section class="sign-in">
          <div class="container">
            <div class="signin-content">
              <div class="signin-image">
                <figure>
                  <img
                    src="https://www.pngkit.com/png/full/250-2509808_real-estate-law-from-the-ground-up-real.png"
                    alt=""
                  />
                </figure>
                
              </div>

              <div class="signin-form">
                <h2 class="form-title">You're a ...</h2>

                  <div class="form-group registerOption">
                    <a href="/registerIndividual" ><i class="fas fa-user"></i> &nbsp;&nbsp;&nbsp; Individual</a>
                  </div>
                  <div class="form-group registerOption">

                    <a href="/registerInstitutional" ><i class="fas fa-users"></i>&nbsp;&nbsp;&nbsp;Business</a>
                  </div>
                  <br/>
                  <a href="/login" class="signup-image-link">
                  Already a member ? Login Here
                </a>
              </div>
              
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

export default RegisterOption;
