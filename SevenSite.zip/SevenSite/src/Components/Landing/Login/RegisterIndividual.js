import React, { Component } from 'react'
import "./Login.css";
import axios from "axios";
import { withRouter } from 'react-router-dom';
class RegisterIndividual extends Component {

  handleSubmit = e =>{
    console.log('form submitted')
    e.preventDefault();
    const data  = {
        first_name : this.fName,
        last_name  : this.lName,
        email : this.email,
        password: this.password,
        phone : this.phone,
        is_corporate: false,
        company_name: "",
        gst_in: "",
        is_phone_verified:true,
        otp:""

    };
    axios.post('https://api.seventhsq.com/auth/api/register/', data).then(
        res => {
console.log(res)
// window.alert("Register Success");
this.props.history.push({
  pathname: `/login`,
  
});
        }
    ).catch(
        err => {
         
            console.log(err)
        }
    )
    console.log(data);
      }
  render(){
    return (
      <div>
         <div className="loginPanel">
      <div class="main">
        <section class="sign-in">
          <div class="container">
            <div class="signin-content">
              <div class="signin-image">
                <figure>
                  <img
                    src="https://www.pngkit.com/png/full/250-2509808_real-estate-law-from-the-ground-up-real.png"
                    alt=""
                  />
                </figure>
                
              </div>

              <div class="signin-form">
                <h2 class="form-title">Sign Up </h2>
                <form onSubmit={this.handleSubmit}>
                  <div class="form-group">
                    <label for="your_name">
                    <i class="fas fa-user"></i>
                    </label>
                    <input
                      type="text"
                      name="your_name"
                      id="your_name"
                      placeholder="First Name"
                      onChange={e => this.fName = e.target.value}
                    />
                  </div>
                  <div class="form-group">
                    <label for="your_name">
                    <i class="fas fa-user"></i>
                    </label>
                    <input
                      type="text"
                      name="your_name"
                      id="your_name"
                      placeholder="Last Name"
                      onChange={e => this.lName = e.target.value}
                    />
                  </div>
                  <div className="row contact_section">
                  <div class="form-group contact_otp">
                    <label for="your_contact">
                    <i class="fas fa-id-card-alt"></i>
                    </label>
                    <input
                      type="number"
                      name="your_contact"
                      id="your_contact"
                      placeholder="Mobile"
                      onChange={e => this.phone = e.target.value}
                    />
                  </div>
                  <div className="otp_section">
                  <button className="btn-dark get_otp" value="Get Otp">Get Otp</button>
                  </div>
                  </div>
                  
                  <div class="form-group">
                    <label for="your_email">
                    <i class="fas fa-envelope-open"></i>
                    </label>
                    <input
                      type="email"
                      name="your_email"
                      id="your_email"
                      placeholder="Email ( Optional )"
                      onChange={e => this.email = e.target.value}
                    />
                  </div>
                  <div class="form-group">
                    <label for="your_pass">
                    <i class="fas fa-key"></i>
                    </label>
                    <input
                      type="password"
                      name="your_pass"
                      id="your_pass"
                      placeholder="Password"
                      onChange={e => this.password = e.target.value}
                    />
                  </div>
                 
                  <div class="form-group form-button">
                    <button
                      type="submit"
                      name="signup"
                      id="signup"
                      class="form-submit"
                    >Create a new Account</button>
                  </div>
                  </form>
               
                <a href="/registerOption" class="signup-image-link">
                Change SignUp Option
                </a>
                <div class="social-login">
                  <span class="social-label">Or SignUp with</span>
                  <ul class="socials">
                    <li>
                      <a href="/icon">
                      <i class="fab fa-facebook-square"></i>
                      </a>
                    </li>
                    <li>
                      <a href="/icon">
                      <i class="fab fa-linkedin"></i>
                      </a>
                    </li>
                    <li>
                      <a href="/icon">
                      <i class="fab fa-google"></i>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
      </div>
    )
  }
}
export default withRouter(RegisterIndividual);