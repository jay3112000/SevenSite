import React from 'react';

import Body from "./Body/Body";
function Landing() {
    return (
        <div>
            <Body />          
        </div>
        
    )
}

export default Landing;
