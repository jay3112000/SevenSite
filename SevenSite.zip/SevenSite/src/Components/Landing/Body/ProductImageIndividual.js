import React, { Component } from 'react'
import axios from "axios"
export default class ProductImageIndividual extends Component {  

    
    constructor(props) {
      super(props);
     
      this.state = {
        posts: [],
      };
    }
    componentDidMount() {
      axios
        .get("https://seller.seventhsq.com/inventory/api/picture/" + this.props.image)
        .then((response) => {
          this.setState({ posts: response.data });
         
         
        })
        .catch((error) => {
          console.log(error);
        });

        
    }
    render(){
        
        return(
          <div>
              { this.state.posts.slice(0, 1).map(curr =>(
              <img src= { "https://seller.seventhsq.com" + curr["picture"]} alt=""  />    
            ))
            }
          </div>
                    

        );
      };
}

