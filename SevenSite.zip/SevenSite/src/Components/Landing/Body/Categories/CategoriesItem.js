
export const catItem = [
    {
        id: "1",
        image : require('./Categories_images/cement.jpg'),
        title : "Cement",

    },
    {
        id: "2",
        image : require('./Categories_images/brick.jpg'),
        title : "Bricks",

    },
    {
        id: "3",
        image : require('./Categories_images/steel.webp'),
        title : "Pipes & Fittings",

    },
    {
        id: "4",
        image : require('./Categories_images/sanitory.jpg'),
        title : "Sanitaryware",

    },
    {
        id: "5",
        image : require('./Categories_images/alumunium.webp'),
        title : "Steel",

    },
    {
        id: "6",
        image :require('./Categories_images/electrical.jpg'),
        title : "Electricals",

    },
    {
        id: "7",
        image : require('./Categories_images/sand.jpg'),
        title : "Aggregates",

    },
    {
        id: "8",
        image : require('./Categories_images/flooring.png'),
        title : "Flooring & wall",

    },
    {
        id: "9",
        image : require('./Categories_images/wood.jpg'),
        title : "wood",

    },
    {
        id: "10",
        image : require('./Categories_images/chemicals.jpg'),
        title : "Chemicals",

    },
    {
        id: "11",
        image : require('./Categories_images/glass.jpg'),
        title : "Glass",

    },
    {
        id: "12",
        image : require('./Categories_images/paint.jpg'),
        title : "Paints & Finishes",

    },
    {
        id: "13",
        image :require('./Categories_images/accesories.png'),
        title : "Hardware",

    },
    {
        id: "14",
        image : require('./Categories_images/modular.png'),
        title : "Modular",

    },
    {
        id: "15",
        image : require('./Categories_images/roofing.jpg'),
        title : "Roofing",

    },
    {
        id: "16",
        image : require('./Categories_images/door.png'),
        title : "Doors & Windows",

    },
  ];