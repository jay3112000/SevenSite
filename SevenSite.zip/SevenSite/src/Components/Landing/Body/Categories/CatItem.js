import React, { useEffect, useState } from "react";
import "./categoriesProduct.css";
function CatItem(props) {
    const[imagedata,setimage]=useState([]);
  
  const getimages=async()=>{
      const res=await fetch(`https://seller.seventhsq.com/inventory/api/picture/${props.id}`);
      const data= await res.json();
      console.log(data);
      setimage(data[0].picture);
      
  }
  useEffect(()=>{
    getimages();
  },[])
    return (
        <div class="content">
        <img
          src={"https://seller.seventhsq.com"+imagedata }
          alt={props.name}
        />
        <h3>{props.name}</h3>

        {/* <p>{curr.description}</p> */}
        <div className="row d-flex my-2">

          <h6>₹{props.price}</h6>
          {/* <h6>{curr.category}</h6> */}
        </div>

        <button class="buy-3">Buy Now</button>
      </div>
    )
}

export default CatItem
