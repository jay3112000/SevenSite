import React, { useEffect, useState } from "react";

import "./categoriesProduct.css";
import CatItem from "./CatItem";
function Cat(props) {
  const [product, setProduct] = useState([]);
  const getProduct = async () => {
    const response = await fetch(
      "https://seller.seventhsq.com/inventory/api/inventory_detail_by_category/" +
        props.name
    );

    setProduct(await response.json());
    
  };
  useEffect(() => {
    getProduct();
  }, []);
  
  return product.map((curr,index) => {
    return (
      //   <div class={'product my-2 ' } key={curr.id}>
      //   <div class="img-container shadow">
      //     <img src={"https://seller.seventhsq.com"+ curr.image} alt={curr.name} width="100px" />

      //   </div>
      //   <div class="bottom shadow">
      //   <p>{curr.name}</p>
      //   <p>{curr.category}</p>
      //   <p>{curr.description}</p>

      //     <div class="price">
      //       <span>₹{curr.sellingPrice}</span>
      //     </div>
      //   </div>
      // </div>
             <CatItem  name={curr.name} price={curr.sellingPrice} key={index} id={curr.id}  />
      
    );
  });
}

export default Cat;
