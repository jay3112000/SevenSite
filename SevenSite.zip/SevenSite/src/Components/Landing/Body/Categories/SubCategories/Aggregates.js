import React from 'react'
import "../Categories.css";
import M from '../Sub Category Icons/M Sand.png'
import P from '../Sub Category Icons/P Sand.png'
import Stone from '../Sub Category Icons/Crushed Stone.png'
function Aggregates() {
    return (
        <div className="categorySection">
         
          <h1 className="text-center mt-5 pt-4">Aggregates</h1>

        <div className="categorySectionOptions">
          <div className="categorySectionItems slide">
            <img
              src={Stone}
              alt=""
            />
            <h5>Crushed Stone</h5>
            {/* <p>1212 pieces</p> */}
          </div>
          <div className="categorySectionItems slide">
            <img
              src={M}
              alt=""
            />
            <h5>M-Sand</h5>
            {/* <p>1212 pieces</p> */}
          </div>
          <div className="categorySectionItems slide">
            <img
              src={P}
              alt=""
            />
            <h5>P-Sand</h5>
            {/* <p>1212 pieces</p> */}
          </div>
          {/* <div className="categorySectionItems slide">
            <img
              src="https://png.pngitem.com/pimgs/s/61-612316_transparent-red-brick-png-bricks-png-png-download.png"
              alt=""
            />
            
          </div> */}
        </div>
      </div>
    )
}

export default Aggregates
