import React from 'react'
import "../Categories.css";
function Glass() {
    return (
        <div className="categorySection">
         
          <h1 className="text-center mt-5 pt-4">All Products</h1>

      </div>
    )
}

export default Glass
