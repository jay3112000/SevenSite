import React from 'react'
import "../Categories.css";
function ReadyMixConcrete() {
    return (
        <div className="categorySection">
         
          <h1 className="text-center mt-5 pt-4">Ready Mix Concrete</h1>

       
        
      </div>
    )
}

export default ReadyMixConcrete
