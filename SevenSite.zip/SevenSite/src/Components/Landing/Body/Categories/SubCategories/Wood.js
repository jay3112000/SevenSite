import React from 'react'
import "../Categories.css";
import LOGS from '../Sub Category Icons/Wood Logs.png'
import VM from '../Sub Category Icons/Veneer & Mica.png'
import BB from '../Sub Category Icons/Blockboard.png'
import PB from '../Sub Category Icons/Particleboard.png'
import MDf from '../Sub Category Icons/MDF.png'
function Wood() {
    return (
        <div className="categorySection">
         
          <h1 className="text-center mt-5 pt-4">Wood</h1>

        <div className="categorySectionOptions">
          <div className="categorySectionItems slide">
            <img
              src={LOGS}
              alt=""
            />
            <h5>Wood Logs</h5>
            {/* <p>1212 pieces</p> */}
          </div>
          <div className="categorySectionItems slide">
            <img
              src={VM}
              alt=""
            />
            <h5>Veneer & Mica</h5>
            {/* <p>1212 pieces</p> */}
          </div>
          <div className="categorySectionItems slide">
            <img
              src={BB}
              alt=""
            />
            <h5>Blockboard</h5>
            {/* <p>1212 pieces</p> */}
          </div>
          <div className="categorySectionItems slide">
            <img
              src={PB}
              alt=""
            />
            <h5>Particleboard</h5>
            {/* <p>1212 pieces</p> */}
          </div>
          <div className="categorySectionItems slide">
            <img
              src={MDf}
              alt=""
            />
            <h5>MDF</h5>
            {/* <p>1212 pieces</p> */}
          </div>
          
        </div>
      </div>
    )
}

export default Wood
