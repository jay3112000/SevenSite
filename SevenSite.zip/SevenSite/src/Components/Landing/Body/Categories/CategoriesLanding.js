import React from "react";
import "./Categories.css";
import Cat from "./Cat";
import {useParams} from "react-router-dom"
import Hardware from "./SubCategories/Hardware";
import HardwareFilter from "./SubCategories/HardwareFilter";
import Bricks from "./SubCategories/Bricks";
import BricksFilter from "./SubCategories/BricksFilter";
import Steel from "./SubCategories/Steel";
import  ReadyMixConcrete from "./SubCategories/ReadymixConrete";
import SteelFilter from "./SubCategories/SteelFilter";
import Aggregates from "./SubCategories/Aggregates";
import ReadyMixConcreteFilter from "./SubCategories/ReadyMixConcreteFilter";

import AggregatesFilter from "./SubCategories/AggregatesFilter";
import Wood from "./SubCategories/Wood";
import WoodFilter from "./SubCategories/WoodFilter";
import Glass from "./SubCategories/Glass";
import GlassFilter from "./SubCategories/GlassFilter";
import Pipes from "./SubCategories/Pipes";
import PipesFilter from "./SubCategories/PipesFilter";
import Sanitaryware from "./SubCategories/Sanitaryware";
import SanitarywareFilter from "./SubCategories/SanitarywareFilter";
import Electrical from "./SubCategories/Electrical";
import ElectricalFilter from "./SubCategories/ElectricalFilter";
import ConstructionChemicals from "./SubCategories/ConstructionChemicals";
import Paints from "./SubCategories/Paints";
import PaintsFilter from "./SubCategories/PaintsFilter";
import BuildingHardware from "./SubCategories/BuildingHardware";
import BuildingHardwareFilter from "./SubCategories/BuildingHardwareFilter";
import Roofing from "./SubCategories/Roofing";
import RoofingFilter from "./SubCategories/RoofingFilter";
import Flooring from "./SubCategories/Flooring";
import FlooringFilter from "./SubCategories/FlooringFilter";
import Doors from "./SubCategories/Doors";
import DoorsFilter from "./SubCategories/DoorsFilter";
function CategoriesLanding() {
  const {name} = useParams();
  
  return (
    <div>
      <div className="container-fluid categoryLanding">
        {
          name=='Hardware'?
          <Hardware/>
         :name=='Bricks'?
         <Bricks/>
         :name=='Steel'?
         <Steel/>
         :name=='Aggregates'?
         <Aggregates/>
         :name=='Ready Mix Concrete'?
         <ReadyMixConcrete/>
         :name=='wood'?
         <Wood/>
         :name=='Glass'?
         <Glass/>
         :name=='Pipes_&_Fittings'?
         <Pipes/>
         :name=='Sanitaryware'?
         <Sanitaryware/>
         :name=='Electricals'?
         <Electrical/>
         :name==' Construction Chemicals'?
         <ConstructionChemicals/>
         :name=='Paints_&_Finishes'?<Paints/>
         :name=='BuildingHardware'?<BuildingHardware/>
         :name=='Roofing'?<Roofing/>
         :name=='Flooring_&_wall'?<Flooring/>
         :name=='Doors_&_Windows'?<Doors/>
         :null
        }
      
        <div className="categoryBody">
          {
            name=='Hardware'? <HardwareFilter/>
            :name=='Bricks'?<BricksFilter/>
            :name=='Steel'?<SteelFilter/>
            :name=='Aggregates'?<AggregatesFilter/>
            :name=='Ready Mix Concrete'?<ReadyMixConcreteFilter/>
            :name=='wood'?<WoodFilter/>
            :name=='Glass'?<GlassFilter/>
            :name=='Pipes_&_Fittings'?<PipesFilter/>
            :name=='Sanitaryware'?<SanitarywareFilter/>
            :name=='Electricals'?<ElectricalFilter/>
            :name=='Construction Chemicals'?<ConstructionChemicals/>
            :name=='Paints_&_Finishes'?<PaintsFilter/>
            :name=='BuildingHardware'?<BuildingHardwareFilter/>
            :name=="Roofing"?<RoofingFilter/>
            :name=='Flooring_&_wall'?<FlooringFilter/>
            :name=='Doors_&_Windows'?<DoorsFilter/>
            :null
          }
        
          <div className="bodyRight">
            <div className="bodyRightHeading">
              <p>Options in {name} </p>
              <div className="sortOption">
                <p>Sort By</p>
                <select class="form-select">
                  <option selected>Relevence</option>
                  <option value="1">Top to Bottom</option>
                  <option value="2">Bottom to Top</option>
                  <option value="3">Popular</option>
                </select>
    
              </div>
              

            </div>
            {/* <div>
              <Cat name={name} />
              </div> */}
              <div class="gallery"> 
              
              <Cat name={name} />
              
    </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CategoriesLanding;
