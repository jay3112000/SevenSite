import React from 'react'
import Testimonial from './Testimonial'
import "../Body/Review.css";
function Review() {
    return (
        <div className='container-lg'>
            <div className="d-flex justify-content-center my-5">
                <h1>Customer Reviews</h1>
                
            </div>
            <div className="d-flex justify-content-center my-5">
            <h4>we love and value all our customers equally every support of user means a lot</h4>
            </div>
            <section class="review" id="review">
        
           <div className='row'>
               <div className='col-md-6 col-sm-12'>
               <div class="box-container my-3">
                      <div class="box">
            <h3>john deo</h3>
            <p>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat,
              quos eum. Laborum aut a consequatur ducimus, molestias possimus
              quisquam rerum temporibus ipsum voluptate accusamus, unde ab
              asperiores? Exercitationem, unde rem.erwfewfwefwefwefwef
            </p>
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="far fa-star"></i>
            </div>
          </div>
          </div>
          <div class="box-container my-3">
          <div class="box">
            <h3>john deo</h3>
            <p>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat,
              quos eum. Laborum aut a consequatur ducimus, molestias possimus
              quisquam rerum temporibus ipsum voluptate accusamus, unde ab
              asperiores? Exercitationem, unde rem.
            </p>
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star-half-alt"></i>
            </div>
          </div>
          </div>
          <div class="box-container my-3">
          <div class="box">
            <h3>john deo</h3>
            <p>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat,
              quos eum. Laborum aut a consequatur ducimus, molestias possimus
              quisquam rerum temporibus ipsum voluptate accusamus, unde ab
              asperiores? Exercitationem, unde rem.
            </p>
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
            </div>
          </div>
        </div>
                </div>
                <div className='col-md-6 col-sm-12'>
               <div class="box-container my-3">
                      <div class="box">
            <h3>john deo</h3>
            <p>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat,
              quos eum. Laborum aut a consequatur ducimus, molestias possimus
              quisquam rerum temporibus ipsum voluptate accusamus, unde ab
              asperiores? Exercitationem, unde rem.erwfewfwefwefwefwef
            </p>
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="far fa-star"></i>
            </div>
          </div>
          </div>
          <div class="box-container my-3">
          <div class="box">
            <h3>john deo</h3>
            <p>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat,
              quos eum. Laborum aut a consequatur ducimus, molestias possimus
              quisquam rerum temporibus ipsum voluptate accusamus, unde ab
              asperiores? Exercitationem, unde rem.
            </p>
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star-half-alt"></i>
            </div>
          </div>
          </div>
          <div class="box-container my-3">
          <div class="box">
            <h3>john deo</h3>
            <p>
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat,
              quos eum. Laborum aut a consequatur ducimus, molestias possimus
              quisquam rerum temporibus ipsum voluptate accusamus, unde ab
              asperiores? Exercitationem, unde rem.
            </p>
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
            </div>
          </div>
        </div>
                </div>
               </div>
               
        
      </section>
            
           
            
        </div>
    )
}

export default Review
