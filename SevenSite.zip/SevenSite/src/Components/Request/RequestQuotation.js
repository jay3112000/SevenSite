import React from 'react'
import "./Request.css"
function RequestQuotation() {
    return (
        <div className="container m-4 requestForQuote">
        <h2>Request For Quotation</h2>
        <hr/>
        <form>
        <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Product Required</label>
        <div class="col-sm-10">
        <input type="text" class="form-control" id="inputEmail3" placeholder="Mention Product Type with Basic Specifications" />
        </div>
        </div>
        <div class="form-group row">
        <label for="inputPassword3" class="col-sm-2 col-form-label">Category</label>
        <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" placeholder="Type or Select from the List Below" />
        </div>
        </div>
        <div class="form-group row">
        <label for="inputPassword3" class="col-sm-2 col-form-label">Brand Preference</label>
        <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" placeholder="Optional" />
        </div>
        </div>
        <div class="form-group row">
        <label for="inputPassword3" class="col-sm-2 col-form-label">Description</label>
        <div class="col-sm-10">
        <textarea class="form-control" placeholder="Include Your Specifications, customisations, dimensions, etc." id="exampleFormControlTextarea1" rows="2"></textarea>
        </div>
        </div>
        <div class="form-group row">
        <label for="inputPassword3" class="col-sm-2 col-form-label">Quantity Required</label>
        <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" placeholder="Please Specify measurement unit too (For Ex. 150 Bags or 25 Tons )" />
        </div>
        </div>
        <div class="form-group row">
        <label for="inputPassword3" class="col-sm-2 col-form-label">Delivery Location</label>
        <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" placeholder="City / District , if multiple please mention" />
        </div> 
        </div>
        <div class="form-group row">
        <label for="inputPassword3" class="col-sm-2 col-form-label">Delivery Timeline</label>
        <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" placeholder="Required Delivery Date / Range" />
        </div>
        </div>
        <div class="form-group row">
        <div class="col-md-12">
        <button type="submit" class="btn btn-dark">Request</button>
        </div>
        </div>
        </form>
            </div>
            )
}

export default RequestQuotation
