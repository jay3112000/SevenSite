import React from 'react'
import axios from "axios";
import { useState, useEffect } from 'react';
import { withRouter } from 'react-router-dom';

import {Container, Row ,Form , Col , Formlabel,FormControl , Button } from 'react-bootstrap'
function Checkout() {
  const [addressdata,setaddress]=useState([])
  const[cartdata,setdata]=useState([]);
  const[userdata,setuserdata]=useState([]);
  const[total,settotal]=useState(0);
  const [baseurl]=useState('https://secure.payu.in/_payment');

  const [title]=useState('Reactjs checkout')
  const [key,setKey]=useState('TiAdHQ')
  const [salt]=useState('fvCfBBGVX1oI8FRB7Bj06o1KjDMWF0ef')
  const [txnid,settxnid]=useState('');
  const [amount, setAmount]=useState('')
  const [firstname,setfirstname]=useState('')
  const [email,setEmail]=useState('j@gmail.com')
  const [phone,setPhone]=useState('8769009977')
  const [productinfo, setproductinfo]=useState('ok')
  const [surl]=useState('https://theseventhsquare.pythonanywhere.com/payu/payu_surl/')
  const [furl]=useState('https://theseventhsquare.pythonanywhere.com/payu/payu_surl/')
  const [serviceProvider]=useState('payu_paisa')
  const [hash,sethash]=useState('')
  let cartItems=[]
  


/////////////////////////////////////////to get hash value
  const gethash=async()=>{
    
    console.log(`amount${amount}`)
    const config = {
      method:'POST',
      headers: {
        'Content-Type': 'application/json',
        
      },
      body:JSON.stringify({
        "amount": amount,
        "productinfo": 'ok',
        "firstname": userdata.first_name,
        "email": userdata.email ,
        
      })
    };
    
    const res=await fetch('https://api.seventhsq.com/payu/hash/',config);
    const data= await res.json();
    console.log(data);
    sethash(data.hash);
    settxnid(data.txnid)
    console.log(data.hash)
    console.log(data.txnid)
    
    
}

//////////////////////////////////////for posting order
  const postorder=async()=>{
    cartdata.forEach(myfn)

    function myfn(item) {
    cartItems.push({
      price:item.price,
     product:item.item,
     quantity:item.quantity
      
    })
  } 
    console.log(cartItems)
    const config = {
      method:'POST',
      headers: {
        Authorization: "token " + localStorage.getItem("token"),
        'Content-Type': 'application/json',
      },
      body:JSON.stringify({
        "address": addressdata.apartment_address,
        "zipcode": addressdata.zip,
        "place": addressdata.street_address,
        "items": cartItems,
        "paid_amount":total,
        "order_success":false,
        "hash":hash,
        "desc":'ok',
        "txnid":txnid

    })
    
    };
    console.log(config.body)
    const res=await fetch('https://api.seventhsq.com/orders/orders/',config);
    window.alert("order placed");
    const data= await res.json();
    console.log(data);
    
}
/////////////////////////////////////////for getting user address data
  const getaddressdata=()=>{
    const config = {
      headers: {
        Authorization: "token " + localStorage.getItem("token"),
      },
    };

    axios
    .get(
      "https://api.seventhsq.com/orders/addresses",
      config
    )
    .then(
      (res) => {
       setaddress(res.data[0])
       console.log(res.data[0])
      },
      (err) => {
        console.log(err);
      }
    );
  }
///////////////////////////////////for getting user data
  const getuserdata=async()=>{
      
    const config = {
      headers: {
          Authorization : 'token ' + localStorage.getItem('token')
      }
  }
  const res=await fetch('https://api.seventhsq.com/user_profile/get_profile/',config);
  const data= await res.json();
  
  setuserdata(data.user);
  console.log(data.user)
  
  

  
    
}
////////////////////////////////////for getting cart details
const getdata=async()=>{
      
  const config = {
    headers: {
      Authorization: "token " + localStorage.getItem("token"),
    },
  };
  console.log(config);
  const res=await fetch('https://api.seventhsq.com/orders/add-to-cart/',config);
  const data= await res.json();
  console.log(data);
  setdata(data);
  let s=0
  data.forEach(myFunction)
  function myFunction(item) {
    s += item.price*item.quantity;
  }
  settotal(s)
  setAmount(s)
  

}
useEffect(()=>{
  getdata();
  getuserdata()
  getaddressdata()
 
},[])
useEffect(()=>{
  gethash();
},[amount,userdata.first_name,userdata.email])





        return (
            <div>
              
                <div class="container">
      <div class="py-5 text-center">
        <h2>Checkout form</h2>
      </div>

      <div class="row">
        <div class="col-md-4 order-md-2 mb-4">
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Your cart</span>
            <span class="badge badge-secondary badge-pill">{cartdata.length}</span>
          </h4>
          <ul class="list-group mb-3">
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h6 class="my-0">Products info</h6>
                <div className='d-flex flex-column bd-highlight mb-3'>

                {
                cartdata.map((curr,index)=>{
                       return(
                        <div class="d-flex flex-row bd-highlight mb-3">
                        <small class="text-muted mx-1" key={index}>{curr.title}</small>
                        <small class="text-muted mx-1" key={index}>{curr.price}</small>
                        <small class="text-muted  mx-1" key={index}>{curr.quantity}</small>
                        </div>
                        
                       )
                })
              }
                </div>
               
              </div>
             

             
            </li>
            {/* <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h6 class="my-0">Second product</h6>
                <small class="text-muted">Brief description</small>
              </div>
              <span class="text-muted">$8</span>
            </li>
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h6 class="my-0">Third item</h6>
                <small class="text-muted">Brief description</small>
              </div>
              <span class="text-muted">$5</span>
            </li> */}
            {/* <li class="list-group-item d-flex justify-content-between bg-light">
              <div class="text-success">
                <h6 class="my-0">Promo code</h6>
                <small>EXAMPLECODE</small>
              </div>
              <span class="text-success">-$5</span>
            </li> */}
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (USD)</span>
              <strong>{total}</strong>
            </li>
          </ul>

          {/* <form class="card p-2">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Promo code" />
              <div class="input-group-append">
                <button type="submit" class="btn btn-secondary">Redeem</button>
              </div>
            </div>
          </form> */}
        </div>
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3">Shipping address</h4>
          <form class="needs-validation" novalidate>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">First name</label>
                <input type="text" class="form-control" id="firstName" placeholder={userdata.first_name} value='' required />
                <div class="invalid-feedback">
                  Valid first name is required.
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" class="form-control" id="lastName" placeholder="" value={userdata.last_name} required />
                <div class="invalid-feedback">
                  Valid last name is required.
                </div>
              </div>
            </div>

            <div class="mb-3">
              <label for="phonenumber">Phone number</label>
              <div class="input-group">
                
                <input type="text" class="form-control" id="phonenumber" placeholder={userdata.username} required />
                <div class="invalid-feedback" >
                  Your Phone number is required.
                </div>
              </div>
            </div>

            <div class="mb-3">
              <label for="email">Email <span class="text-muted"></span></label>
              <input type="email" class="form-control" id="email" placeholder={userdata.email} />
              <div class="invalid-feedback">
                Please enter a valid email address for shipping updates.
              </div>
            </div>
        
            
            <hr class="mb-4" />
            <div class="custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input" id="same-address" />
              <label class="custom-control-label" for="same-address">Shipping address is the same as my billing address</label>
            </div>
            <div class="custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input" id="save-info" />
              <label class="custom-control-label" for="save-info">Save this information for next time</label>
            </div>
           

           
           
          
            <hr class="mb-4" />
            <div className='row d-flex justify-content-evenly'>
              <div className='col-md-4 pt-5'>
              <button class="btn btn-primary btn-md btn-block mt-5" type="submit">Go back</button>
              </div>
              <div className='col-md-4'>
              <div>
            <Form action={baseurl} method="post">
               
                <Row className='pt-sm-2'>
                     
                      <Col sm>
                          <Form.Control type="hidden" name='key' value={key} >
                              
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                      
                      <Col sm>
                          <Form.Control type="hidden" name='salt' value={salt} >
                              
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                      
                      <Col sm>
                          <Form.Control type="hidden" name='txnid' value={txnid} >
                              
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                      
                      <Col sm>
                          <Form.Control type="hidden" name='amount' value={amount} >
                             
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                      
                      <Col sm>
                          <Form.Control type="hidden" name='firstname' value={userdata.first_name} >
                              
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                     
                      <Col sm>
                          <Form.Control type="hidden" name='email' value={userdata.email} >
                              
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                     
                      <Col sm>
                          <Form.Control type="hidden" name='phone' value={phone} >
                              
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                      
                      <Col sm>
                          <Form.Control type="hidden" name='productinfo' value={'ok'} >
                              
                          </Form.Control>
                      </Col>
                </Row>
               
               
                <Row className='pt-sm-2'>
                      
                      <Col sm>
                          <Form.Control type="hidden" name='surl' value={surl} readonly>
                             
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                     
                      <Col sm>
                          <Form.Control type="hidden" name='furl' value={furl} readonly>
                             
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                     
                      <Col sm>
                          <Form.Control type="hidden" name='serviceprovider' value={serviceProvider} readonly>
                             
                          </Form.Control>
                      </Col>
                </Row>
                <Row className='pt-sm-2'>
                     
                      <Col sm>
                          <Form.Control type="hidden" name='hash' value={hash} readonly>
                             
                          </Form.Control>
                      </Col>
                </Row>
                {/* <Row className='pt-sm-2'>
                      <Col sm>
                          <Button type='submit'>
                                 Pay
                          </Button>
                      </Col>
                      
                </Row> */}
                 <Button class="btn btn-primary btn-lg btn-block " type="submit" onClick={postorder} >Continue to checkout</Button>
            </Form>
        </div>
             
             
              
              </div>
              
            </div>
            
          </form>
        </div>
      </div>

      <footer class="my-5 pt-5 text-muted text-center text-small">
        <p class="mb-1">&copy; 2017-2018 Company Name</p>
        <ul class="list-inline">
          <li class="list-inline-item"><a href="/">Privacy</a></li>
          <li class="list-inline-item"><a href="/">Terms</a></li>
          <li class="list-inline-item"><a href="/">Support</a></li>
        </ul>
      </footer>
    </div>
            </div>
        )
    }
export default withRouter(Checkout);
