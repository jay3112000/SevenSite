import React, { useContext } from "react";
import Items from "./Items";
import { CartContext } from "../../App";
import { useState, useEffect,useCallback } from 'react';
import { useHistory } from "react-router-dom";
import {FaRegFolder} from "react-icons/fa"
import axios from "axios";
import "./cart.css"
import { BrowserRouter as Link } from "react-router-dom";

const ContextCart = () => {
  const { item ,totalItem, totalAmount } = useContext(CartContext);
  const [addressdata,setaddress]=useState([])
  const[cartdata,setdata]=useState([]);
  const[total,settotal]=useState(0);
  const[j,setj]=useState(0);
  let cartItems=[]
  let cartProduct={}

   let history = useHistory();

    const Verify=async()=>{
      const token= await localStorage.getItem('token')
   console.log(token)
   if(token==null){
      history.push("/login");
    
   }

    }
    const getaddressdata=()=>{
      const config = {
        headers: {
          Authorization: "token " + localStorage.getItem("token"),
        },
      };

      axios
      .get(
        "https://api.seventhsq.com/orders/addresses",
        config
      )
      .then(
        (res) => {
         setaddress(res.data)
         console.log(res)
        },
        (err) => {
          console.log(err);
        }
      );
    }

   
    
    const getdata=async()=>{
      
      const config = {
        headers: {
          Authorization: "token " + localStorage.getItem("token"),
        },
      };
      console.log(config);
      const res=await fetch('https://api.seventhsq.com/orders/add-to-cart/',config);
      const data= await res.json();
      console.log(data);
      setdata(data);
      let s=0
      data.forEach(myFunction)
      function myFunction(item) {
        s += item.price*item.quantity;
      }
      settotal(s)
      
    
  }
 
  const incrementcart=useCallback(async(title,oldprice,pcksize,price,item)=>{
    
    const config = {
      method:'POST',
      headers: {
        Authorization: "token " + localStorage.getItem("token"),
        'Content-Type': 'application/json',
      },
      body:JSON.stringify({
        "title": title,
          "oldprice": oldprice,
          "pcksize": pcksize,
          "estdelivery": '1' ,
          "price": price ,
          "quantity": 1,
          "item": item,
        
      })
    };
    console.log(config);
    const res=await fetch('https://api.seventhsq.com/orders/add-to-cart/',config);
    
    const data= await res.json();
    console.log(data);
    setj(j+1)
    
    
  },[j])
  
  const decrementcart=useCallback(async(title,oldprice,pcksize,price,item)=>{
    const config = {
      method:'POST',
      headers: {
        Authorization: "token " + localStorage.getItem("token"),
        'Content-Type': 'application/json',
      },
      body:JSON.stringify({
        "title": title,
        "oldprice": oldprice,
        "pcksize": pcksize,
        "estdelivery": '1' ,
        "price": price ,
        "quantity": -1,
        "item": item,
      })
    };
    console.log(config);
    const res=await fetch('https://api.seventhsq.com/orders/add-to-cart/',config);
    const data= await res.json();
    setj(j+1)
    console.log(data);
    
    
},[j])

const removecart=useCallback(async(title,oldprice,pcksize,price,item)=>{
    
  const config = {
    method:'POST',
    headers: {
      Authorization: "token " + localStorage.getItem("token"),
      'Content-Type': 'application/json',
    },
    body:JSON.stringify({
      "title": title,
        "oldprice": oldprice,
        "pcksize": pcksize,
        "estdelivery": '1' ,
        "price": price ,
        "quantity": -10000,
        "item": item,
      
    })
  };
  console.log(config);
  const res=await fetch('https://api.seventhsq.com/orders/add-to-cart/',config);
  
  const data= await res.json();
  setj(j+1)
  console.log(data);
  
  
},[j])

useEffect(()=>{
  Verify();
},[])

useEffect(()=>{
  getdata();
  
},[incrementcart,decrementcart,removecart])

useEffect(()=>{
  
  getaddressdata();
},[])


  return (
    <>
      
      {cartdata.length>0?
      <div>
        <div class="container-fluid">
          <h2 class="text-center text-dark py-4 h1">My Cart</h2>
          <h5  class="text-center text-dark py-2"> Total Products: {cartdata.length} </h5>
          <div class="row">
            <div class="col-md-10 col-11 mx-auto">
              <div class="row mt-5 gx-3">
                <div class="col-md-12 col-lg-8 col-11 mx-auto main_cart mb-lg-0 mb-2 ">
                  {/* your items goes here */}
                  
                    {cartdata.map((curItem,index) => {
                      return <Items key={curItem.id} {...curItem} incrementcart={incrementcart}
                      decrementcart={decrementcart} removecart={removecart}
                       />;
                    })}
                  
                </div>

                <div class="col-md-12 col-lg-4 col-11 mx-auto mt-lg-0 mt-md-5 cart-right_section">
                  <div class="right_side p-3 shadow bg-white">
                    <h5 class=" h5 product_name mb-3">Summary</h5>
                    <div class="price_indiv d-flex justify-content-between">
                      <p>Product amount</p>
                      <p>
                       <span id="product_total_amt">₹ {total}</span>
                      </p>
                    </div>
                    <div class="price_indiv d-flex justify-content-between">
                      <p>GST</p>
                      <p>
                       <span id="gst_charge">₹ 50.0</span>
                      </p>
                    </div>
                   
                  </div>
                  <div
                    class="
                  container-fluid
                    total-amt
                    d-flex
                    
                    font-weight-bold
                  "
                  >
                    <p>Cart Total </p>
                    <p id="total_cart_amt">
                     <span>₹ {totalAmount}</span>
                    </p>
                  </div>
                 
                  
                    <button className="btncheckoutbutton text-uppercase btn btn-dark mt-5"><a href={'/checkout'} >  Proceed to Checkout</a></button>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      :
      <>
        <h1 class="text-center text-dark mt -5 pt-5 py-4 h1">Your Cart is Empty</h1>
        <h5 class="text-center text-dark mt-4">Please add some products</h5>
        <FaRegFolder size={155} className='mx-auto mt-5'/>
        </>
         }


    </>
  );
};

export default ContextCart;


