import React from 'react'
import "./Blog.css";
import "./Responsive.css";
function Tags(props) {
    return (
        <div>
             <a href="#" class="fh5co_tagg">
                  {props.title}
                </a>
                
                
        </div>
    )
}

export default Tags
