import React, {useEffect, useState} from "react";
import {useParams} from "react-router-dom"
import { useHistory } from "react-router-dom";
import axios from 'axios';
import "./accordion";
import Quotation from "./Quotation";
import Testimonial from "../Landing/Body/Testimonial";
import Blogs from "../Landing/Body/Benefits/Blog/Blogs"
// import { FaLessThan } from "react-icons/fa";
// import { FaGreaterThan } from "react-icons/fa";
import "./product.css";
import { FaArrowDown } from "react-icons/fa";
import { BrowserRouter as router, Link } from "react-router-dom";
import ProductImage from "./ProductImage";
import BrandName from "./BrandName";
import Rfqmodal from "./Rfomodal";
import Rfpmodal from "./Rfpmodal";
import Bpoform from "./Bpoform";
import InfoModal from "./InfoModal";

// import Image1 from "../../images/1.jpg";
// import Image2 from "../../images/2.png";
// import Image3 from "../../images/3.jpg";
// import MainProduct from "../Landing/Body/MainProduct";
// import "./Scroll";
function Product() {
  const {id} = useParams();
  const NewID = id.toString();
  const [users, setUsers] = useState([]);
  const [brands, setBrand] = useState([]);
  const[reviews,setreviews]=useState([]);
  const[totalreview,settotalreview]=useState(0);
  let history = useHistory();
  const [RfqmodalShow, setRfqModalShow] = useState(false);
  const [RfpmodalShow, setRfpModalShow] = useState(false);
  const [BpomodalShow, setBpoModalShow] = useState(false);
  const [InfomodalShow, setInfoModalShow] = useState(false);
  const getreviews=async()=>{
    
    const config = {
      
      headers: {
        Authorization: "token " + localStorage.getItem("token"),
        'Content-Type': 'application/json',
      }
    }
    const res=await fetch(`https://api.seventhsq.com/orders/review_get_by_product/${NewID}`,config);
    const data= await res.json();
    console.log(`reviews${data}`);
    let l=data.length
    let s=0
    setreviews(data);

    data.forEach(myFunction)
      function myFunction(item) {
        s += item.star;
      }
      settotalreview(s/l)
      console.log(totalreview)
  
    
    
}
  const getUsers = async () =>{
    console.log(`id${NewID}`)
    const response  = await fetch('https://seller.seventhsq.com/inventory/api/inventory_detail/' + NewID);
    const brand  = await fetch('https://seller.seventhsq.com/account/companyname/' + NewID);
    setUsers(await response.json());
    setBrand(await brand.json());
    console.log(await response.json())
  }



  const addtocart=async()=>{
    
    const config = {
      method:'POST',
      headers: {
        Authorization: "token " + localStorage.getItem("token"),
        'Content-Type': 'application/json',
      },
      body:JSON.stringify({
        "title": users.name,
        "oldprice": users.markedPrice,
        "pcksize": '3',
        "estdelivery": '1' ,
        "price": users.sellingPrice ,
        "quantity": 1,
        "item": users.id,
        "gst":users.gstRate
        
      })
    };
    console.log(config);
    const res=await fetch('https://api.seventhsq.com/orders/add-to-cart/',config);
    window.alert("Added to Cart");
    const data= await res.json();
    console.log(data);
    
    
}

const buynow=async()=>{
    
  const config = {
    method:'POST',
    headers: {
      Authorization: "token " + localStorage.getItem("token"),
      'Content-Type': 'application/json',
    },
    body:JSON.stringify({
      "title": users.name,
      "oldprice": users.markedPrice,
      "pcksize": '3',
      "estdelivery": '1' ,
      "price": users.sellingPrice ,
      "quantity": 1,
      "item": users.id,
      "gst":users.gstRate
      
    })
  };
  console.log(config);
  const res=await fetch('https://api.seventhsq.com/orders/add-to-cart/',config);
  const data= await res.json();
  console.log(data);
  history.push("/checkout");
  
  
}

  useEffect (() => {
    getUsers()
    getreviews()
  },[])
  
  
  return (

    <div>
      <div id="content-wrapper" key={users.id}>
        <div class="column">
          <ProductImage
          image = {NewID}
          />
          <div class="social-links">
            <p>Share on </p>
            <a href="/icon">
              <i class="fab fa-facebook-f"></i>
            </a>
            <a href="/icon">
              <i class="fab fa-twitter"></i>
            </a>
            <a href="/icon">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="/icon">
              <i class="fab fa-whatsapp"></i>
            </a>
            <a href="/icon">
              <i class="fab fa-pinterest"></i>
            </a>
          </div>
        </div>

        <div class="column">
          <div class="col-md-12">
            <h2 class="product-title">{users.name}</h2>
            <a href="/brand" class="product-link">
              {brands.companyName}
            </a>
            <div class="product-detail">
              <p>
                {users.description}
              </p>
            </div>

            <div class="price-col">
              <div class="product-price">
                <p class="last-price">
                  Price : <span>₹ {users.markedPrice} </span>&nbsp;&nbsp;
                </p>
                <p class="new-price">
                  <span><i class="fa-solid fa-indian-rupee-sign"></i> {users.sellingPrice} ({users.discount})%</span>
                </p>
                
              </div>
              <div class="product-rating">
                              {totalreview=>0 && totalreview<=1?
                                <i class="fas fa-star"></i>:null
                               }
                                {totalreview>1 && totalreview<=2?
                                <>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                </>
                                :null
                               }
                               {totalreview>2 && totalreview<=3?
                                <>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                </>
                                :null
                               }
                               {totalreview>3 && totalreview<=4?
                                <>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                </>
                                :null
                               }
                                {totalreview>4 && totalreview<=5?
                                <>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                </>
                                :null
                               }
                                
                <span>{Math.ceil(totalreview)}/5</span>
              </div>
            </div>
            <div class="exclusiveGst">
              {
                users.incl_gst?
                <span > ( Exclusive of GST {users.gstRate}% )</span>:
                <span > ( Inclusive of GST {users.gstRate}% )</span>

              }
           
            </div>
            <div class="delivery-info">
              <input
                class="checkDelivery"
                type="number"
                placeholder="Enter Your Pincode"
              />
              <button
                type="button"
                class="btn btn-primary btn-md mr-1 mb-2 deliveryButton"
              >
                Check Delivery
              </button>
            </div>
            <div class="purchase-info">
              <div class="minimumorder">
                <input class="purchaseinput" type="number" placeholder="1" />
                <p>( M.O.Q. : {users.qty} )</p>
              </div>

              <button onClick={addtocart}   class="btn btn-light btn-md mr-1 mb-2">
                <i class="fas fa-shopping-cart pr-2"></i>Add to cart
              </button>
              <button type="button" class="btn btn-light btn-md mr-1 mb-2" onClick={buynow}>
                &nbsp;Buy Now
              </button>
            </div>
            <div className="productaccordian">
              <input
                className="productAccordianInput"
                type="checkbox"
                id="title1"
              />
              {users.category && '3' && users.weight && users.width?
              <>
               <label className="productAccordianLabel" for="title1">
               Product Specifications
                 <span>
                   <FaArrowDown />
                 </span>{" "}
               </label>
               <div class="accordianContent">
                <p>
                  Product Type : <span>{users.category}</span>
                </p>
                <p>
                  Product Weight : <span>{users.weight}</span>
                </p>
                <p>
                  Product Dimension : <span>{users.length}{users.width}{users.height}</span>
                </p>
              </div>
               
               </>:
               null
              
              }
             

              <input
                className="productAccordianInput"
                type="checkbox"
                id="title2"
              />
              {
                users.aboutBrand?
                <>
                <label className="productAccordianLabel" for="title2">
                  About the Brand
                  <span>
                    <FaArrowDown />
                  </span>
                </label>
  
                <div class="accordianContent">
                  <p>
                    <span>{users.aboutBrand} </span>
                  </p>
                </div>
                   </>:
                   null
              }
             
              <input
                className="productAccordianInput"
                type="checkbox"
                id="title3"
              />
              {users.aboutUsage?
              <>
                     <label className="productAccordianLabel" for="title3">
              Usage
                <span>
                  <FaArrowDown />
                </span>
              </label>

              <div class="accordianContent">
                <p>{users.aboutUsage}</p>
              </div>
              </>:null
            }
             
              <input
                className="productAccordianInput"
                type="checkbox"
                id="title4"
              />

              {
                users.aboutStorage?
                <>
                <label className="productAccordianLabel" for="title4">
              Storage
                <span>
                  <FaArrowDown />
                </span>
              </label>

              <div class="accordianContent">
                <p>{users.aboutStorage}</p>
              </div>
                </>:null
              }
              
              <input
                className="productAccordianInput"
                type="checkbox"
                id="title5"
              />
              {users.aboutInstallation?
            <>
              <label className="productAccordianLabel" for="title5">
              Installation
                <span>
                  <FaArrowDown />
                </span>
              </label>

              <div class="accordianContent">
                <p>{users.aboutInstallation}</p>
              </div>
            </>:null
            }
              
              <input
                className="productAccordianInput"
                type="checkbox"
                id="title6"
              />

              {users.aboutHandling?
               <>
                <label className="productAccordianLabel" for="title6">
              Handling
                <span>
                  <FaArrowDown />
                </span>
              </label>

              <div class="accordianContent">
                <p>{users.aboutHandling}
                </p>
              </div>
               </>:null
            }
              <input
                className="productAccordianInput"
                type="checkbox"
                id="title7"
              />
               <label className="productAccordianLabel" for="title7">
                Reviews
                <span>
                  <FaArrowDown />
                </span>
              </label>
              <div class="accordianContent">
                { 
                  reviews.length>0?
                  reviews.map((curr,index)=>{
                         return(
                          
                           <div>
                           
                             <h4>
                               {curr.title}
                             </h4>
                             <div class="review-rating">
                               {curr.star=='1'?
                                <i class="fas fa-star"></i>:null
                               }
                                {curr.star=='2'?
                                <>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                </>
                                :null
                               }
                               {curr.star=='3'?
                                <>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                </>
                                :null
                               }
                               {curr.star=='4'?
                                <>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                </>
                                :null
                               }
                                {curr.star=='5'?
                                <>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                </>
                                :null
                               }
                                
                                <span>{curr.star}/5</span>
                              </div>
                             <p>
                               {curr.review}
                             </p>
                             </div>
                         )
                  }):null
                }
              </div>
              
            </div>
          </div>

       
            
         
            
         
             
              
          {/* <Quotation/> */}
          <div>
             <div >
          <h2 className="quotationHeading">Request for : </h2>
        </div>
      <div class="quotationwrapper">
       

        <button className='m-3' onClick={() => setRfqModalShow(true)}>
        <div class="button">
          <div class="icon">
            Quotation
            </div>
        </div>
        </button>

        <button class="className='m-3'"  onClick={() => setInfoModalShow(true)}>
        <div class="button">
          <div class="icon">Information</div>
        </div>
        </button>

        <button class="className='m-3'"  onClick={() => setRfpModalShow(true)}>
        <div class="button">
          <div class="icon">Proposal</div>
        </div>
        </button>

        <button class="className='m-3'"  onClick={() => setBpoModalShow(true)}>
        <div class="button">
          <div class="icon">Blanket PO</div>
        </div>
        </button>

      </div>
    </div>
        </div>
      </div>
      <section class="section products">
        <div class="title">
          <span class="h2 my-2">Bought Together</span>
        </div>
        <div class="product-layout">
          
        </div>
      </section>
      <section class="section products">
        <div class="title">
          <span class="h2 my-2">Related Products</span>
        </div>
        <div class="product-layout">
          
          
          

          
        </div>
      </section>
<Blogs/>
      <Testimonial />
              <Rfqmodal
               show={RfqmodalShow}
               onHide={() => setRfqModalShow(false)}
              />
              <Rfpmodal
              show={RfpmodalShow}
              onHide={() => setRfpModalShow(false)}
              />
              <Bpoform
              show={BpomodalShow}
              onHide={() => setBpoModalShow(false)}
              />
              <InfoModal
              show={InfomodalShow}
              onHide={() => setInfoModalShow(false)}
              />
             
    </div>
  );
}

export default Product;