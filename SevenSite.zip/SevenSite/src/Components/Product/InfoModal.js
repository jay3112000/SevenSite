import React from 'react'
import { Button,Modal} from 'react-bootstrap'; 
import Form from 'react-bootstrap/Form'

import "bootstrap/dist/css/bootstrap.min.css";
function InfoModal(props) {
    return (
        <div>
             <Modal
             {...props}
             size="lg"
             aria-labelledby="contained-modal-title-vcenter"
             centered
             animation={false}
            >  
               
		<Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Information Form
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <h4>Please fill the details</h4>
        </Modal.Body>
        <Form.Group className='mx-3 my-2' >
			<Form >
           
              <Form.Label className='mt-4'>Details</Form.Label>
              <Form.Control as="textarea" rows={6}  placeholder="Details" /> 
              
               
             
			  <Button className='mx-4 mt-4' type='submit' >SUBMIT</Button>  
            </Form>  
          </Form.Group>
          
		  
		  
		  <Modal.Footer>   
			
            
          </Modal.Footer>  
        </Modal> 
            
            
        </div>
    )
}

export default InfoModal
