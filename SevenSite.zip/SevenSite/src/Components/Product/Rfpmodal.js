import React from 'react'
import { Button,Modal} from 'react-bootstrap'; 
import Form from 'react-bootstrap/Form'

import "bootstrap/dist/css/bootstrap.min.css";

function Rfpmodal(props) {
    return (
        <div>
             <Modal
             {...props}
             size="lg"
             aria-labelledby="contained-modal-title-vcenter"
             centered
             animation={false}
            >  
               
		<Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            RFQ Form
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <h4>Please fill the details</h4>
        </Modal.Body>
        <Form.Group className='mx-3 my-2' >
			<Form >
            <div class="d-flex justify-content-evenly">
            
              <Form.Control type="text"   placeholder="Product Required"  />    
             
              <Form.Control type="text"   placeholder="Category"  /> 
                </div> 
                <div class="d-flex justify-content-evenly mt-4">
                <Form.Control type="text"   placeholder="Brand Preference (Optional)" /> 
                <Form.Control type="text"   placeholder="Quantity Required" />
                </div>

                <div class="d-flex justify-content-evenly mt-4">
                <Form.Control type="text"   placeholder="Delivery Location" /> 
                <Form.Control type="text"   placeholder="Delivery Timeline" /> 

                    </div>
             
             
              
              <Form.Label className='mt-4'>Description</Form.Label>
              <Form.Control as="textarea" rows={5}  placeholder="Description" /> 
              
               
             
			  <Button className='mx-4 mt-4' type='submit' >SUBMIT</Button>  
            </Form>  
          </Form.Group>
          
		  
		  
		  <Modal.Footer>   
			
            
          </Modal.Footer>  
        </Modal> 
            
        </div>
    )
}

export default Rfpmodal
